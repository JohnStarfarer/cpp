//Behavioral

#include <iostream>
#include <vector>

// ��������
template <typename T>
class Iterator {
public:
    virtual ~Iterator() {}
    virtual T next() = 0;
    virtual bool hasNext() = 0;
};

// ���������� �������� ��� �������
template <typename T>
class VectorIterator : public Iterator<T> {
private:
    std::vector<T>& collection;
    size_t index;

public:
    VectorIterator(std::vector<T>& collection) : collection(collection), index(0) {}

    T next() override {
        return collection[index++];
    }

    bool hasNext() override {
        return index < collection.size();
    }
};

// ���������
template <typename T>
class Collection {
private:
    std::vector<T> items;

public:
    void add(const T& item) {
        items.push_back(item);
    }

    VectorIterator<T> createIterator() {
        return VectorIterator<T>(items);
    }
};


//int main() {
//    Collection<int> collection;
//    collection.add(1);
//    collection.add(2);
//    collection.add(3);
//
//    VectorIterator<int> iterator = collection.createIterator();
//    while (iterator.hasNext()) {
//        std::cout << iterator.next() << " ";
//    }
//
//    return 0;
//}
