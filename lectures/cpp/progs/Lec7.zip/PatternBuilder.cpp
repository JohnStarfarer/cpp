//Creational

#include <iostream>
#include <string>
// �������
class Pizza {
public:
    std::string dough;
    std::string sauce;
    std::string topping;

    void describe() {
        std::cout << "Pizza with " << dough << " dough, "
            << sauce << " sauce, and "
            << topping << " topping." << std::endl;
    }
};

// ����������� ���������
class PizzaBuilder {
public:
    virtual void buildDough() = 0;
    virtual void buildSauce() = 0;
    virtual void buildTopping() = 0;
    virtual Pizza* getPizza() = 0;
};

// ���������� ���������
class HawaiianPizzaBuilder : public PizzaBuilder {
private:
    Pizza* pizza;

public:
    HawaiianPizzaBuilder() {
        pizza = new Pizza();
    }

    void buildDough() override {
        pizza->dough = "cross";
    }

    void buildSauce() override {
        pizza->sauce = "mild";
    }

    void buildTopping() override {
        pizza->topping = "ham and pineapple";
    }

    Pizza* getPizza() override {
        return pizza;
    }
};

// �����������, ������������ ���������
class PizzaDirector {
private:
    PizzaBuilder* builder;

public:
    void setBuilder(PizzaBuilder* b) {
        builder = b;
    }

    Pizza* constructPizza() {
        builder->buildDough();
        builder->buildSauce();
        builder->buildTopping();
        return builder->getPizza();
    }
};


//int main() {
//    PizzaDirector director;
//    HawaiianPizzaBuilder hawaiianBuilder;
//
//    director.setBuilder(&hawaiianBuilder);
//    Pizza* pizza = director.constructPizza();
//    pizza->describe();
//
//    
//    delete pizza;
//
//    return 0;
//}
