//Creational
#include <iostream>
#include <memory>

// ����������� ��������
class Button {
public:
    virtual void render() = 0;
    virtual ~Button() = default;
};

class TextField {
public:
    virtual void render() = 0;
    virtual ~TextField() = default;
};

// ���������� ��������
class DarkButton : public Button {
public:
    void render() override {
        std::cout << "Dark Button rendered\n";
    }
};

class DarkTextField : public TextField {
public:
    void render() override {
        std::cout << "Dark TextField rendered\n";
    }
};

class LightButton : public Button {
public:
    void render() override {
        std::cout << "Light Button rendered\n";
    }
};

class LightTextField : public TextField {
public:
    void render() override {
        std::cout << "Light TextField rendered\n";
    }
};

// ����������� �������
class WidgetFactory {
public:
    virtual std::unique_ptr<Button> createButton() = 0;
    virtual std::unique_ptr<TextField> createTextField() = 0;
    virtual ~WidgetFactory() = default;
};

//���������� �������
class DarkThemeFactory : public WidgetFactory {
public:
    std::unique_ptr<Button> createButton() override {
        return std::make_unique<DarkButton>();
    }

    std::unique_ptr<TextField> createTextField() override {
        return std::make_unique<DarkTextField>();
    }
};

class LightThemeFactory : public WidgetFactory {
public:
    std::unique_ptr<Button> createButton() override {
        return std::make_unique<LightButton>();
    }

    std::unique_ptr<TextField> createTextField() override {
        return std::make_unique<LightTextField>();
    }
};

//int main() {
//    std::unique_ptr<WidgetFactory> factory;
//
//    
//    factory = std::make_unique<DarkThemeFactory>();
//
//    
//    auto button = factory->createButton();
//    auto textField = factory->createTextField();
//
//    
//    button->render();
//    textField->render();
//
//    
//    factory = std::make_unique<LightThemeFactory>();
//    button = factory->createButton();
//    textField = factory->createTextField();
//
//    button->render();
//    textField->render();
//
//    return 0;
//}